# ArrowScore for Android

Native Kotlin Android starter project for voice-first darts scoring.

## Features included
- 301, 501, and Cricket setup for 1–4 players
- Optional double-out for 301/501
- Voice recognition for one dart at a time (e.g. “single 20”, “double 20”, “triple 19”, “outer bull”, “double bull”, “miss”)
- Spoken prompts for each dart and the next player
- Live score / Cricket marks, visual board with the current visit's darts, and checkout suggestions
- Manual dart entry and undo
- Keeps the display awake while a game is active

## Build an APK using GitHub Actions from a phone

This project includes `.github/workflows/android-apk.yml`. GitHub Actions builds the Android app on a hosted Linux runner, so Android Studio is not needed on the phone.

1. Create a GitHub account if you do not already have one, then create a **new private repository** named `ArrowScoreAndroid`.
2. Extract this ZIP on your phone.
3. Upload the contents of the extracted `ArrowScoreAndroid` folder to the root of that repository. Keep the `.github/workflows/android-apk.yml` path intact. If GitHub's mobile upload page makes folders difficult, use GitHub's desktop site view or a GitHub-connected tool to upload the project files.
4. Open the repository's **Actions** tab and select **Build ArrowScore APK**.
5. Tap **Run workflow** if it has not started automatically after the upload.
6. When the run finishes successfully, open that workflow run and download the **ArrowScore-debug-APK** artifact.
7. Extract the downloaded artifact ZIP, tap `app-debug.apk`, and allow Android to install apps from that source if prompted. Then install and allow microphone access when ArrowScore first opens.

The workflow uses Java 17, Gradle 8.9, Android SDK 35, and saves the generated APK as a downloadable workflow artifact.

## Notes / current limitations
- This is a debug APK for personal testing, not a Play Store release.
- Continuous recognition is implemented by restarting Android's speech recognizer after each phrase and after spoken prompts. Android/OEM speech services can still time out or interrupt listening; the screen shows listening/reconnecting status and manual entry remains available.
- Voice recognition expects one dart result per phrase. Speak clearly and pause briefly after each dart. Supported examples: “single 5”, “double 20”, “triple 19”, “bull”, “outer bull”, “double bull”, “miss”.
- Checkout suggestions are common double-out routes, not guaranteed optimal strategy.
- Cricket scoring is a basic standard implementation; verify house rules before serious play.
