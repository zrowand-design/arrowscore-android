package com.arrowscore.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(16, 24, 32)
    private val panel = Color.rgb(29, 40, 50)
    private val gold = Color.rgb(224, 165, 43)
    private val white = Color.WHITE
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null
    private var listening = false
    private var ttsReady = false
    private var gameStarted = false
    private var playerCount = 2
    private var gameType = "501"
    private var doubleOut = true
    private val names = mutableListOf("Player 1", "Player 2", "Player 3", "Player 4")
    private val scores = mutableListOf(501, 501, 501, 501)
    private val cricketMarks = Array(4) { IntArray(7) }
    private val history = mutableListOf<Snapshot>()
    private var currentPlayer = 0
    private var dartsThisTurn = 0
    private var turnStartScore = 501
    private var lastMessage = "Ready"
    private val turnDarts = mutableListOf<Dart>()
    private var winner = -1
    private var board: DartboardView? = null
    private var statusText: TextView? = null
    private var scoreText: TextView? = null
    private var turnText: TextView? = null
    private var checkoutText: TextView? = null
    private var micText: TextView? = null
    private var logText: TextView? = null
    private var root: LinearLayout? = null

    data class Dart(val number: Int, val multiplier: Int, val label: String, val points: Int) {
        val isDouble: Boolean get() = multiplier == 2
    }
    data class Snapshot(val scores: List<Int>, val marks: List<List<Int>>, val player: Int, val darts: Int,
                        val turnStart: Int, val turnDarts: List<Dart>, val winner: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this, this)
        showSetup()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.US
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) { handler.post { restartListening() } }
                override fun onDone(utteranceId: String?) { handler.post { if (gameStarted && winner < 0) restartListening() } }
            })
        }
    }

    private fun baseScreen(title: String): LinearLayout {
        val scroller = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 22) }
        val heading = TextView(this).apply { text = title; textSize = 28f; setTextColor(gold); gravity = Gravity.CENTER; setPadding(0, 8, 0, 18); setTypeface(null, android.graphics.Typeface.BOLD) }
        col.addView(heading)
        scroller.addView(col)
        setContentView(scroller)
        root = col
        return col
    }

    private fun addText(parent: LinearLayout, text: String, size: Float = 16f, color: Int = white): TextView {
        return TextView(this).also { it.text = text; it.textSize = size; it.setTextColor(color); it.setPadding(4, 7, 4, 7); parent.addView(it) }
    }
    private fun addButton(parent: LinearLayout, text: String, action: () -> Unit): Button {
        return Button(this).also { it.text = text; it.isAllCaps = false; it.setOnClickListener { action() }; parent.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 5; bottomMargin = 5 }) }
    }
    private fun showSetup() {
        gameStarted = false
        val col = baseScreen("ARROWSCORE")
        addText(col, "Set up your game", 20f, white)
        addText(col, "Number of players")
        val count = Spinner(this)
        count.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("1 player", "2 players", "3 players", "4 players"))
        count.setSelection((playerCount - 1).coerceIn(0, 3)); col.addView(count)
        addText(col, "Game")
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("501", "301", "Cricket"))
        type.setSelection(listOf("501", "301", "Cricket").indexOf(gameType).coerceAtLeast(0)); col.addView(type)
        val double = CheckBox(this).apply { text = "Double-out (501 / 301)"; setTextColor(white); isChecked = doubleOut; col.addView(this) }
        val fields = mutableListOf<EditText>()
        for (i in 0..3) {
            val e = EditText(this).apply { setSingleLine(); hint = "Player ${i + 1} name"; setText(names[i]); setTextColor(white); setHintTextColor(Color.LTGRAY); setBackgroundColor(panel); setPadding(12, 8, 12, 8); visibility = if (i < playerCount) View.VISIBLE else View.GONE }
            fields.add(e); col.addView(e)
        }
        count.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { playerCount = position + 1; fields.forEachIndexed { i, e -> e.visibility = if (i < playerCount) View.VISIBLE else View.GONE } }
        }
        type.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { gameType = listOf("501", "301", "Cricket")[position]; double.isEnabled = gameType != "Cricket" }
        }
        addButton(col, "START GAME") {
            playerCount = count.selectedItemPosition + 1
            gameType = type.selectedItem.toString(); doubleOut = double.isChecked
            fields.forEachIndexed { i, e -> names[i] = e.text.toString().trim().ifBlank { "Player ${i + 1}" } }
            startGame()
        }
    }

    private fun startGame() {
        val start = if (gameType == "301") 301 else 501
        for (i in 0..3) scores[i] = if (gameType == "Cricket") 0 else start
        for (p in 0..3) cricketMarks[p].fill(0)
        currentPlayer = 0; dartsThisTurn = 0; turnStartScore = start; turnDarts.clear(); history.clear(); winner = -1
        gameStarted = true
        showGame()
        speak("${names[0]}, take your shots")
        ensureMicPermission()
    }

    private fun showGame() {
        val col = baseScreen("ARROWSCORE  •  $gameType")
        val scoreboard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10); setBackgroundColor(panel) }
        col.addView(scoreboard)
        scoreText = addText(scoreboard, "", 19f, gold)
        turnText = addText(col, "", 20f, white)
        board = DartboardView(this).apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 310); setBackgroundColor(Color.TRANSPARENT) }
        col.addView(board)
        checkoutText = addText(col, "", 17f, gold)
        statusText = addText(col, "", 16f, white)
        micText = addText(col, "🎙 Microphone: waiting", 15f, Color.GREEN)
        logText = addText(col, "", 14f, Color.LTGRAY)
        val manual = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(manual)
        addButton(col, "Enter / correct a dart manually") { manualDartDialog() }
        addButton(col, "Undo last dart") { undo() }
        addButton(col, "Repeat player prompt") { speak("${names[currentPlayer]}, take shot ${dartsThisTurn + 1}") }
        addButton(col, "Pause microphone") { stopListening(); micText?.text = "🎙 Microphone paused — tap Resume"; addButton(col, "Resume microphone") { ensureMicPermission(); startListening() } }
        addButton(col, "End game / new game") { stopListening(); showSetup() }
        refreshGame()
    }

    private fun refreshGame() {
        val rows = (0 until playerCount).joinToString("\n") { i ->
            val active = if (i == currentPlayer && winner < 0) "  ◀" else ""
            if (gameType == "Cricket") "${names[i]}    ${cricketMarks[i].joinToString(" ") { m -> "●".repeat(m.coerceAtMost(3)) + "○".repeat((3 - m).coerceAtLeast(0)) }}$active"
            else "${names[i]}    ${scores[i]}$active"
        }
        scoreText?.text = rows
        turnText?.text = if (winner >= 0) "${names[winner]} WINS!" else "${names[currentPlayer]}  •  Dart ${dartsThisTurn + 1} of 3"
        checkoutText?.text = if (gameType == "Cricket" || winner >= 0) "" else "Finish: ${checkout(scores[currentPlayer])}"
        statusText?.text = lastMessage
        micText?.text = if (listening) "🎙 LISTENING — say the dart" else "🎙 Microphone: restarting / paused"
        logText?.text = "This turn: " + if (turnDarts.isEmpty()) "No darts yet" else turnDarts.joinToString("  •  ") { it.label }
        board?.darts = turnDarts.toList(); board?.invalidate()
    }

    private fun saveSnapshot() {
        history.add(Snapshot(scores.toList(), cricketMarks.map { it.toList() }, currentPlayer, dartsThisTurn, turnStartScore, turnDarts.toList(), winner))
    }
    private fun undo() {
        if (history.isEmpty()) { lastMessage = "Nothing to undo"; refreshGame(); return }
        val s = history.removeAt(history.lastIndex)
        s.scores.forEachIndexed { i, v -> scores[i] = v }
        s.marks.forEachIndexed { i, row -> row.forEachIndexed { j, v -> cricketMarks[i][j] = v } }
        currentPlayer = s.player; dartsThisTurn = s.darts; turnStartScore = s.turnStart; turnDarts.clear(); turnDarts.addAll(s.turnDarts); winner = s.winner
        lastMessage = "Last dart undone"; refreshGame(); speak("Undone. ${names[currentPlayer]}, shot ${dartsThisTurn + 1}")
    }

    private fun acceptDart(dart: Dart) {
        if (!gameStarted || winner >= 0) return
        saveSnapshot()
        if (gameType == "Cricket") applyCricket(dart) else applyX01(dart)
        turnDarts.add(dart); dartsThisTurn++
        refreshGame()
        if (winner >= 0) { stopListening(); speak("Game shot! ${names[winner]} wins!"); return }
        if (dartsThisTurn >= 3) {
            val spoken = if (gameType == "Cricket") "${names[currentPlayer]}, turn complete" else "${names[currentPlayer]}, ${turnStartScore - scores[currentPlayer]} points this turn"
            currentPlayer = (currentPlayer + 1) % playerCount; dartsThisTurn = 0; turnDarts.clear(); turnStartScore = scores[currentPlayer]
            refreshGame(); speak("$spoken. ${names[currentPlayer]}, take your shots")
        } else {
            speak("Shot ${dartsThisTurn + 1}")
        }
    }

    private fun applyX01(d: Dart) {
        val before = scores[currentPlayer]
        val after = before - d.points
        if (after < 0 || (doubleOut && after == 1) || (doubleOut && after == 0 && !d.isDouble)) {
            scores[currentPlayer] = turnStartScore
            dartsThisTurn = 2 // bust ends the visit
            lastMessage = "BUST — score returned to $turnStartScore"
            return
        }
        scores[currentPlayer] = after
        lastMessage = "${d.label}  •  ${d.points} points"
        if (after == 0) winner = currentPlayer
    }

    private fun applyCricket(d: Dart) {
        if (d.number !in 15..20 && d.number != 25) { lastMessage = "${d.label} — no Cricket target"; return }
        val idx = if (d.number == 25) 6 else 20 - d.number
        val old = cricketMarks[currentPlayer][idx]
        val newTotal = old + d.multiplier
        val extra = (newTotal - 3).coerceAtLeast(0)
        cricketMarks[currentPlayer][idx] = newTotal.coerceAtMost(3)
        if (extra > 0) {
            val targetClosedByOthers = (0 until playerCount).filter { it != currentPlayer }.all { cricketMarks[it][idx] >= 3 }
            if (!targetClosedByOthers) scores[currentPlayer] -= extra * if (d.number == 25) 25 else d.number
        }
        val allClosed = (0..6).all { cricketMarks[currentPlayer][it] >= 3 }
        val othersBehind = (0 until playerCount).filter { it != currentPlayer }.any { scores[currentPlayer] >= scores[it] }
        if (allClosed && othersBehind) winner = currentPlayer
        lastMessage = "${d.label} recorded"
    }

    private fun manualDartDialog() {
        val choices = arrayOf("Miss", "Single", "Double", "Triple", "Outer bull (25)", "Double bull (50)")
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 8) }
        val mult = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, choices); layout.addView(this) }
        val number = EditText(this).apply { hint = "Number (1–20; ignored for bull/miss)"; inputType = 2; layout.addView(this) }
        AlertDialog.Builder(this).setTitle("Enter dart result").setView(layout).setNegativeButton("Cancel", null).setPositiveButton("Record") { _, _ ->
            val idx = mult.selectedItemPosition
            val n = number.text.toString().toIntOrNull() ?: 20
            val d = when (idx) {
                0 -> Dart(0, 0, "Miss", 0)
                1 -> Dart(n.coerceIn(1,20), 1, "Single $n", n.coerceIn(1,20))
                2 -> Dart(n.coerceIn(1,20), 2, "Double $n", n.coerceIn(1,20)*2)
                3 -> Dart(n.coerceIn(1,20), 3, "Triple $n", n.coerceIn(1,20)*3)
                4 -> Dart(25, 1, "Outer bull", 25)
                else -> Dart(25, 2, "Double bull", 50)
            }
            acceptDart(d)
        }.show()
    }

    private fun checkout(score: Int): String {
        if (score <= 0 || score > 170) return "—"
        val options = mutableListOf<Dart>()
        for (n in 1..20) { options.add(Dart(n,1,"S$n",n)); options.add(Dart(n,2,"D$n",2*n)); options.add(Dart(n,3,"T$n",3*n)) }
        options.add(Dart(25,1,"25",25)); options.add(Dart(25,2,"Bull",50))
        val doubles = options.filter { it.isDouble }
        for (a in options) {
            if (a.points == score && a.isDouble) return a.label
            for (b in options) {
                if (a.points + b.points == score && b.isDouble) return "${a.label}, ${b.label}"
                for (c in doubles) if (a.points + b.points + c.points == score) return "${a.label}, ${b.label}, ${c.label}"
            }
        }
        return if (score <= 40 && score % 2 == 0) "D${score/2}" else "Set up a double"
    }

    private fun parseVoice(raw: String): Dart? {
        var s = raw.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        if (s.isBlank()) return null
        s = s.replace(Regex("\\b(shot|dart|number|uh|um)\\b"), " ").trim()
        s = s.replace(Regex("^(one|two|three|1|2|3)\\s+"), "").trim()
        if (s.contains("miss") || s.contains("no score") || s == "zero") return Dart(0,0,"Miss",0)
        if (s.contains("double bull") || s.contains("bullseye") || s.contains("inner bull") || s.contains("50")) return Dart(25,2,"Double bull",50)
        if (s.contains("outer bull") || s.contains("single bull") || s == "bull" || s.contains("25")) return Dart(25,1,"Outer bull",25)
        val multiplier = when {
            s.contains("triple") || Regex("\\bt\\s*\\d+").containsMatchIn(s) -> 3
            s.contains("double") || Regex("\\bd\\s*\\d+").containsMatchIn(s) -> 2
            else -> 1
        }
        val match = Regex("(?:single|double|triple|[sdt])?\\s*(20|19|18|17|16|15|14|13|12|11|10|[1-9])\\b").find(s) ?: return null
        val n = match.groupValues[1].toInt()
        val label = when(multiplier) { 3 -> "Triple $n"; 2 -> "Double $n"; else -> "Single $n" }
        return Dart(n,multiplier,label,n*multiplier)
    }

    private fun ensureMicPermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
        else startListening()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening()
        else { lastMessage = "Microphone permission is required for voice scoring"; refreshGame() }
    }
    private fun startListening() {
        if (!gameStarted || winner >= 0 || isFinishing) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { lastMessage = "Speech recognition is not available on this phone"; refreshGame(); return }
        try {
            if (speech == null) speech = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { listening = true; runOnUiThread { refreshGame() } }
                    override fun onBeginningOfSpeech() { listening = true }
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { listening = false }
                    override fun onError(error: Int) { listening = false; runOnUiThread { micText?.text = "🎙 Reconnecting microphone…"; if (gameStarted && winner < 0) handler.postDelayed({ startListening() }, 700) } }
                    override fun onResults(results: Bundle?) {
                        listening = false
                        val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        runOnUiThread {
                            if (heard != null) {
                                val dart = parseVoice(heard)
                                if (dart != null) { lastMessage = "Heard: $heard"; acceptDart(dart) }
                                else { lastMessage = "Didn't catch a dart result: $heard"; refreshGame(); speak("Please repeat that shot") }
                            }
                            if (heard == null && gameStarted && winner < 0) handler.postDelayed({ startListening() }, 500)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            }
            speech?.startListening(intent)
        } catch (e: Exception) { listening = false; lastMessage = "Mic error: ${e.localizedMessage ?: "unable to start"}"; refreshGame() }
    }
    private fun restartListening() {
        if (!gameStarted || winner >= 0) return
        stopListening(); handler.postDelayed({ startListening() }, 350)
    }
    private fun stopListening() {
        listening = false
        try { speech?.stopListening(); speech?.cancel() } catch (_: Exception) {}
    }
    private fun speak(text: String) {
        if (!ttsReady) { restartListening(); return }
        stopListening()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "arrow-${System.currentTimeMillis()}")
    }

    override fun onPause() { super.onPause(); stopListening() }
    override fun onResume() { super.onResume(); if (gameStarted && winner < 0) handler.postDelayed({ startListening() }, 500) }
    override fun onDestroy() { stopListening(); speech?.destroy(); tts?.shutdown(); super.onDestroy() }

    inner class DartboardView(context: android.content.Context) : View(context) {
        var darts: List<Dart> = emptyList()
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val nums = intArrayOf(20,1,18,4,13,6,10,15,2,17,3,19,7,16,8,11,14,9,12,5)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width/2f; val cy = height/2f; val r = minOf(width,height)*0.43f
            p.style = Paint.Style.FILL; p.color = Color.rgb(8,8,8); canvas.drawCircle(cx,cy,r+5,p)
            val start = -99f; val sweep = 18f
            for (i in 0 until 20) {
                val a = start + i*sweep
                val color1 = if (i%2==0) Color.rgb(220,220,205) else Color.rgb(30,30,30)
                val color2 = if (i%2==0) Color.rgb(190,35,35) else Color.rgb(25,125,75)
                drawRing(canvas,cx,cy,r*0.96f,r*0.88f,a,sweep,color2)
                drawRing(canvas,cx,cy,r*0.88f,r*0.53f,a,sweep,color1)
                drawRing(canvas,cx,cy,r*0.53f,r*0.47f,a,sweep,color2)
                drawRing(canvas,cx,cy,r*0.47f,r*0.12f,a,sweep,color1)
                p.color = white; p.textSize = r*0.11f; p.textAlign = Paint.Align.CENTER
                val rad = Math.toRadians((a+9).toDouble()); canvas.drawText(nums[i].toString(),cx+cos(rad).toFloat()*r*1.08f,cy+sin(rad).toFloat()*r*1.08f+r*0.035f,p)
            }
            p.color = Color.rgb(30,125,75); canvas.drawCircle(cx,cy,r*0.12f,p)
            p.color = Color.rgb(190,35,35); canvas.drawCircle(cx,cy,r*0.055f,p)
            darts.forEachIndexed { index, d ->
                val angle = Math.toRadians((start + ((nums.indexOf(d.number).coerceAtLeast(0))*sweep) + 9).toDouble())
                val rr = when(d.multiplier) { 3 -> r*0.62f; 2 -> r*0.91f; else -> r*0.72f }
                val x = if (d.number == 25) cx + (index-1)*r*0.08f else cx+cos(angle).toFloat()*rr
                val y = if (d.number == 25) cy + (index-1)*r*0.08f else cy+sin(angle).toFloat()*rr
                p.color = gold; p.style = Paint.Style.FILL; canvas.drawCircle(x,y,r*0.055f,p)
                p.color = Color.BLACK; p.textSize = r*0.06f; canvas.drawText((index+1).toString(),x,y+r*0.02f,p)
            }
        }
        private fun drawRing(c: Canvas,cx:Float,cy:Float,outer:Float,inner:Float,start:Float,sweep:Float,color:Int) {
            p.color=color; p.style=Paint.Style.FILL
            val rect=RectF(cx-outer,cy-outer,cx+outer,cy+outer); c.drawArc(rect,start,sweep,true,p)
            p.color=Color.BLACK; p.style=Paint.Style.STROKE; p.strokeWidth=1f
            val innerRect=RectF(cx-inner,cy-inner,cx+inner,cy+inner); c.drawArc(innerRect,start,sweep,true,p); p.style=Paint.Style.FILL
        }
    }
}
